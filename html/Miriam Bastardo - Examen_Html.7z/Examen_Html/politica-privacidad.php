<?php
$titulo = "Política de Privacidad";
  $description = "Contenido de la presentación de Política de Privacidad";
  include("_partials/header.php");
?>
<article>
		<h1>
			<?php echo $titulo; ?>
		</h1>
	</article>
  <!-- Contenido principal -->
<main>
	

	<h1>"Quién no vive para servir, no sirve para vivir"</h1><br>

</main>
	<?php 
	include("_partials/footer.php")
	 ?>