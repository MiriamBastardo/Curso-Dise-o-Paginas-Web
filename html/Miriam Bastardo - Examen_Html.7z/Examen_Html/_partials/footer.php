 <button onclick="window.location.href='index.php'">Volver</button> 
  <br>
  <br>
  
  <footer>
    <address>
      
      Teléfonos:<br>  
      <a href="tel:+34%680%365%455">[+34 680 365 455]</a><br> 
      <a href="mailto:miriam.bastardo@gmail.com">miriam.bastardo@gmail.com</a><br> 
       <a href="https://wa.me/?text=Quiero%20contactar%20contigo" target="_blank">WhastApp</a>
        <h3>Sígueme en mis redes sociales:</h3>
    <p>
        <!-- Instagram -->
        <a href="https://www.instagram.com/miriambasloz/" target="_blank" title="Instagram">
            <img src="https://upload.wikimedia.org/wikipedia/commons/a/a5/Instagram_icon.png" alt="Instagram" width="40" height="40">
        </a>
        
        <!-- Facebook -->
        <a href="https://www.facebook.com/miriambastardolozada/" target="_blank" title="Facebook">
            <img src="https://upload.wikimedia.org/wikipedia/commons/5/51/Facebook_f_logo_%282019%29.svg" alt="Facebook" width="40" height="40">
        </a>
        
        <!-- LinkedIn -->
        <a href="https://www.linkedin.com/in/miriambastardo/" target="_blank" title="LinkedIn">
            <img src="https://upload.wikimedia.org/wikipedia/commons/e/e9/Linkedin_icon.svg" alt="LinkedIn" width="40" height="40">
        </a>
    </p>
    </address>
     
     
    <a href="#">Política de Cookies</a><br>  
    <a href="#">Política de Privacidad</a><br> 
    <div class="copyright">
            <div class="container">
              <div class="row">
                <div class="col-md-12">
                  <p>
                    © 2024 Todos los derechos reservados. Diseñado por
                    <a href="https://miriambastardo.wixsite.com/podcast">Miriam Bastardo</a>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

  </footer>

</html>
